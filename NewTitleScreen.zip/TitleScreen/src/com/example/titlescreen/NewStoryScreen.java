package com.example.titlescreen;

import android.app.Activity;
import android.os.Bundle;
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentTabHost;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;

public class NewStoryScreen extends Activity {

    protected void onCreate(Bundle b) {
        super.onCreate(b);

        setContentView(R.layout.new_screen);
    
    //upon clicking button, add story to database
    }
    
}